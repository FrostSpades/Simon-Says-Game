/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../cs3505-assignment6-FrostSpades/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "startButtonPressed",
    "",
    "playerSelectionComplete",
    "selection",
    "on_redButton_clicked",
    "on_blueButton_clicked",
    "on_startButton_clicked",
    "on_brRadioButton_clicked",
    "on_ypRadioButton_clicked",
    "glowButton",
    "buttonId",
    "timeToBeLit",
    "disableGameButtons",
    "enableGameButtons",
    "showStartScreen",
    "updateScreenPlayerTurn",
    "newPercentage",
    "updateScreenComputerTurn",
    "showGameOverScreen"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[40];
    char stringdata0[11];
    char stringdata1[19];
    char stringdata2[1];
    char stringdata3[24];
    char stringdata4[10];
    char stringdata5[21];
    char stringdata6[22];
    char stringdata7[23];
    char stringdata8[25];
    char stringdata9[25];
    char stringdata10[11];
    char stringdata11[9];
    char stringdata12[12];
    char stringdata13[19];
    char stringdata14[18];
    char stringdata15[16];
    char stringdata16[23];
    char stringdata17[14];
    char stringdata18[25];
    char stringdata19[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 18),  // "startButtonPressed"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 23),  // "playerSelectionComplete"
        QT_MOC_LITERAL(55, 9),  // "selection"
        QT_MOC_LITERAL(65, 20),  // "on_redButton_clicked"
        QT_MOC_LITERAL(86, 21),  // "on_blueButton_clicked"
        QT_MOC_LITERAL(108, 22),  // "on_startButton_clicked"
        QT_MOC_LITERAL(131, 24),  // "on_brRadioButton_clicked"
        QT_MOC_LITERAL(156, 24),  // "on_ypRadioButton_clicked"
        QT_MOC_LITERAL(181, 10),  // "glowButton"
        QT_MOC_LITERAL(192, 8),  // "buttonId"
        QT_MOC_LITERAL(201, 11),  // "timeToBeLit"
        QT_MOC_LITERAL(213, 18),  // "disableGameButtons"
        QT_MOC_LITERAL(232, 17),  // "enableGameButtons"
        QT_MOC_LITERAL(250, 15),  // "showStartScreen"
        QT_MOC_LITERAL(266, 22),  // "updateScreenPlayerTurn"
        QT_MOC_LITERAL(289, 13),  // "newPercentage"
        QT_MOC_LITERAL(303, 24),  // "updateScreenComputerTurn"
        QT_MOC_LITERAL(328, 18)   // "showGameOverScreen"
    },
    "MainWindow",
    "startButtonPressed",
    "",
    "playerSelectionComplete",
    "selection",
    "on_redButton_clicked",
    "on_blueButton_clicked",
    "on_startButton_clicked",
    "on_brRadioButton_clicked",
    "on_ypRadioButton_clicked",
    "glowButton",
    "buttonId",
    "timeToBeLit",
    "disableGameButtons",
    "enableGameButtons",
    "showStartScreen",
    "updateScreenPlayerTurn",
    "newPercentage",
    "updateScreenComputerTurn",
    "showGameOverScreen"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   98,    2, 0x06,    1 /* Public */,
       3,    1,   99,    2, 0x06,    2 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,  102,    2, 0x08,    4 /* Private */,
       6,    0,  103,    2, 0x08,    5 /* Private */,
       7,    0,  104,    2, 0x08,    6 /* Private */,
       8,    0,  105,    2, 0x08,    7 /* Private */,
       9,    0,  106,    2, 0x08,    8 /* Private */,
      10,    2,  107,    2, 0x0a,    9 /* Public */,
      13,    0,  112,    2, 0x0a,   12 /* Public */,
      14,    0,  113,    2, 0x0a,   13 /* Public */,
      15,    0,  114,    2, 0x0a,   14 /* Public */,
      16,    1,  115,    2, 0x0a,   15 /* Public */,
      18,    0,  118,    2, 0x0a,   17 /* Public */,
      19,    0,  119,    2, 0x0a,   18 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'startButtonPressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'playerSelectionComplete'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_redButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_blueButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_startButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_brRadioButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ypRadioButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'glowButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'disableGameButtons'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableGameButtons'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showStartScreen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateScreenPlayerTurn'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'updateScreenComputerTurn'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showGameOverScreen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->startButtonPressed(); break;
        case 1: _t->playerSelectionComplete((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->on_redButton_clicked(); break;
        case 3: _t->on_blueButton_clicked(); break;
        case 4: _t->on_startButton_clicked(); break;
        case 5: _t->on_brRadioButton_clicked(); break;
        case 6: _t->on_ypRadioButton_clicked(); break;
        case 7: _t->glowButton((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 8: _t->disableGameButtons(); break;
        case 9: _t->enableGameButtons(); break;
        case 10: _t->showStartScreen(); break;
        case 11: _t->updateScreenPlayerTurn((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->updateScreenComputerTurn(); break;
        case 13: _t->showGameOverScreen(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (_t _q_method = &MainWindow::startButtonPressed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (_t _q_method = &MainWindow::playerSelectionComplete; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::startButtonPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void MainWindow::playerSelectionComplete(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
